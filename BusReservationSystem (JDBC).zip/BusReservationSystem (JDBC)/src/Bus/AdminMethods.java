package Bus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

//======= Admin Methods =======
public class AdminMethods 
{
    public static void addBus() throws SQLException 
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Bus Name: ");
        String busName = sc.nextLine();

        System.out.print("Enter Source: ");
        String source = sc.nextLine();

        System.out.print("Enter Destination: ");
        String destination = sc.nextLine();

        System.out.print("Enter Total Seats: ");
        int totalSeats = sc.nextInt();

        // For new bus, available seats = total seats
        int availableSeats = totalSeats;

        Connection con = null;
        PreparedStatement pst = null;
        
        con = DBUtil.getConnection();

        String query = "INSERT INTO buses (bus_name, source, destination, total_seats, available_seats) VALUES (?, ?, ?, ?, ?)";
        pst = con.prepareStatement(query);
        pst.setString(1, busName);
        pst.setString(2, source);
        pst.setString(3, destination);
        pst.setInt(4, totalSeats);
        pst.setInt(5, availableSeats);

        int rows = pst.executeUpdate();

        if (rows > 0) 
        {
            System.out.println("Bus added successfully!");
        } 
        else 
        {
            System.out.println("Failed to add bus.");
        }
    }

    public static void viewAllBuses() throws SQLException 
    {
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        
        con = DBUtil.getConnection();
        System.out.println("Connection : " + con);
        st = con.createStatement();
        rs = st.executeQuery("SELECT * FROM buses");

        System.out.println("\n--- List of Available Buses ---");
        System.out.printf("%-10s %-20s %-15s %-15s %-12s %-15s\n",
                "Bus ID", "Bus Name", "Source", "Destination", "Total Seats", "Available Seats");

        while (rs.next()) 
        {
            int id = rs.getInt("bus_id");
            String name = rs.getString("bus_name");
            String source = rs.getString("source");
            String destination = rs.getString("destination");
            int total = rs.getInt("total_seats");
            int available = rs.getInt("available_seats");

            System.out.printf("%-10d %-20s %-15s %-15s %-12d %-15d\n",
                    id, name, source, destination, total, available);
        }
    }
}
