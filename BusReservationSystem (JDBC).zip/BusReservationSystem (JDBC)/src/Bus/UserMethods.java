package Bus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

//======= User Methods =======
public class UserMethods 
{
    public static void searchBusesByRoute() throws SQLException 
    {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter source: ");
        String source = sc.nextLine().trim();

        System.out.print("Enter destination: ");
        String destination = sc.nextLine().trim();

        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        
        con = DBUtil.getConnection();
        String query = "SELECT * FROM buses WHERE source = ? AND destination = ?";
        pst = con.prepareStatement(query);
        pst.setString(1, source);
        pst.setString(2, destination);

        rs = pst.executeQuery();

        boolean found = false;
        System.out.println("\nAvailable Buses:");
        System.out.printf("%-10s %-20s %-15s %-15s %-12s %-15s\n",
                          "Bus ID", "Bus Name", "Source", "Destination", "Total Seats", "Available Seats");

        while (rs.next()) 
        {
            int id = rs.getInt("bus_id");
            String name = rs.getString("bus_name");
            String src = rs.getString("source");
            String dest = rs.getString("destination");
            int total = rs.getInt("total_seats");
            int available = rs.getInt("available_seats");

            System.out.printf("%-10d %-20s %-15s %-15s %-12d %-15d\n",
                              id, name, src, dest, total, available);
            found = true;
        }

        if (!found) 
        {
            System.out.println("No buses found for the given route.");
        }
    }
    
    public static void bookTicket(String username) throws SQLException 
    {
        Scanner sc = new Scanner(System.in);
        Connection con = null;
        PreparedStatement pstCheck = null;
        PreparedStatement pstUpdate = null;
        PreparedStatement pstBook = null;
        ResultSet rs = null;
        ResultSet generatedKeys = null;
        
        System.out.print("Enter Bus ID to book: ");
        int busId = sc.nextInt();
        sc.nextLine(); // consume newline

        System.out.print("Enter your name: ");
        String passengerName = sc.nextLine();

        System.out.print("Enter number of seats to book: ");
        int seatsToBook = sc.nextInt();

        con = DBUtil.getConnection();
        con.setAutoCommit(false); // Start transaction

        // Step 1: Check seat availability
        String checkQuery = "SELECT available_seats FROM buses WHERE bus_id = ?";
        pstCheck = con.prepareStatement(checkQuery);
        pstCheck.setInt(1, busId);
        rs = pstCheck.executeQuery();

        if (rs.next()) {
            int availableSeats = rs.getInt("available_seats");

            if (availableSeats >= seatsToBook) {
                // Step 2: Update available seats
                String updateQuery = "UPDATE buses SET available_seats = available_seats - ? WHERE bus_id = ?";
                pstUpdate = con.prepareStatement(updateQuery);
                pstUpdate.setInt(1, seatsToBook);
                pstUpdate.setInt(2, busId);
                pstUpdate.executeUpdate();

                // Step 3: Insert booking
                String bookQuery = "INSERT INTO bookings (bus_id, passenger_name, seats_booked, booking_date) VALUES (?, ?, ?, CURDATE())";
                pstBook = con.prepareStatement(bookQuery, Statement.RETURN_GENERATED_KEYS); // Important
                pstBook.setInt(1, busId);
                pstBook.setString(2, passengerName);
                pstBook.setInt(3, seatsToBook);
                pstBook.executeUpdate();

                // Step 4: Get generated booking_id
                generatedKeys = pstBook.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int bookingId = generatedKeys.getInt(1); // First auto-generated key
                    con.commit(); // Commit transaction
                    System.out.println("✅ Booking successful!");
                    System.out.println("🧾 Your Booking ID is: " + bookingId);
                } else {
                    throw new SQLException("Booking failed, no ID obtained.");
                }
            } else {
                System.out.println("⚠️ Only " + availableSeats + " seats available. Booking failed.");
                con.rollback();
            }
        } else {
            System.out.println("❌ Invalid Bus ID. Booking failed.");
            con.rollback();
        }
    }
    
    public static void cancelBooking() throws SQLException 
    {
        Scanner sc = new Scanner(System.in);
        Connection con = null;
        PreparedStatement pstCheck = null;
        PreparedStatement pstDelete = null;
        PreparedStatement pstUpdate = null;
        ResultSet rs = null;
        
        System.out.print("Enter your Booking ID to cancel: ");
        int bookingId = sc.nextInt();

        con = DBUtil.getConnection();
        con.setAutoCommit(false); // Start transaction

        // Step 1: Check if booking exists
        String checkQuery = "SELECT bus_id, seats_booked FROM bookings WHERE booking_id = ?";
        pstCheck = con.prepareStatement(checkQuery);
        pstCheck.setInt(1, bookingId);
        rs = pstCheck.executeQuery();

        if (rs.next()) {
            int busId = rs.getInt("bus_id");
            int seatsToReturn = rs.getInt("seats_booked");

            // Step 2: Delete the booking
            String deleteQuery = "DELETE FROM bookings WHERE booking_id = ?";
            pstDelete = con.prepareStatement(deleteQuery);
            pstDelete.setInt(1, bookingId);
            pstDelete.executeUpdate();

            // Step 3: Update the available seats
            String updateQuery = "UPDATE buses SET available_seats = available_seats + ? WHERE bus_id = ?";
            pstUpdate = con.prepareStatement(updateQuery);
            pstUpdate.setInt(1, seatsToReturn);
            pstUpdate.setInt(2, busId);
            pstUpdate.executeUpdate();

            con.commit(); // Commit transaction
            System.out.println("✅ Booking canceled successfully.");
        } else {
            System.out.println("❌ Booking not found.");
            con.rollback(); // Rollback if booking is not found
        }
    }
    
    public static void viewBookingDetails(int bookingId) throws SQLException 
    {
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        
        con = DBUtil.getConnection();

        // Step 1: Retrieve booking details based on booking_id
        String query = "SELECT b.booking_id, b.passenger_name, b.seats_booked, bs.bus_name, bs.source, bs.destination " +
                       "FROM bookings b INNER JOIN buses bs ON b.bus_id = bs.bus_id WHERE b.booking_id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, bookingId); // Use 'booking_id' to find the booking details
        rs = pst.executeQuery();

        boolean found = false;
        System.out.println("\nBooking Details:");
        System.out.printf("%-12s %-20s %-15s %-20s %-15s %-15s\n", 
                          "Booking ID", "Passenger Name", "Seats", "Bus Name", "Source", "Destination");

        while (rs.next()) 
        {
            int id = rs.getInt("booking_id");
            String name = rs.getString("passenger_name");
            int seats = rs.getInt("seats_booked");
            String busName = rs.getString("bus_name");
            String source = rs.getString("source");
            String destination = rs.getString("destination");

            System.out.printf("%-12d %-20s %-15d %-20s %-15s %-15s\n", 
                              id, name, seats, busName, source, destination);
            found = true;
        }

        if (!found) 
        {
            System.out.println("❌ No booking found with this ID.");
        }
    }
}
