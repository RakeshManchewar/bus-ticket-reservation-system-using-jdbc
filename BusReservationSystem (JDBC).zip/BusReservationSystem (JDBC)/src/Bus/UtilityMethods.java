package Bus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

//======= Utility Methods =======
public class UtilityMethods 
{
    public static void checkSeatAvailability() throws SQLException 
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Bus ID to check seat availability: ");
        int busId = sc.nextInt();

        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        
        con = DBUtil.getConnection();

        String query = "SELECT bus_name, available_seats FROM buses WHERE bus_id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, busId);
        rs = pst.executeQuery();

        if (rs.next()) 
        {
            String busName = rs.getString("bus_name");
            int availableSeats = rs.getInt("available_seats");

            System.out.println("Bus Name: " + busName);
            System.out.println("Available Seats: " + availableSeats);
        } 
        else 
        {
            System.out.println("No bus found with ID: " + busId);
        }
    }

    public static void updateSeatCount() throws SQLException 
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Bus ID to update: ");
        int busId = sc.nextInt();

        System.out.print("What do you want to update?\n1. Total Seats\n2. Available Seats\nChoose option: ");
        int choice = sc.nextInt();

        Connection con = null;
        PreparedStatement pst = null;
        
        con = DBUtil.getConnection();

        if (choice == 1) 
        {
            System.out.print("Enter new total seats: ");
            int totalSeats = sc.nextInt();
            String query = "UPDATE buses SET total_seats = ? WHERE bus_id = ?";
            pst = con.prepareStatement(query);
            pst.setInt(1, totalSeats);
            pst.setInt(2, busId);
        } 
        else if (choice == 2) 
        {
            System.out.print("Enter new available seats: ");
            int availableSeats = sc.nextInt();
            String query = "UPDATE buses SET available_seats = ? WHERE bus_id = ?";
            pst = con.prepareStatement(query);
            pst.setInt(1, availableSeats);
            pst.setInt(2, busId);
        } 
        else 
        {
            System.out.println("Invalid choice.");
            return;
        }

        int rowsUpdated = pst.executeUpdate();
        if (rowsUpdated > 0) 
        {
            System.out.println("Seat count updated successfully.");
        } 
        else 
        {
            System.out.println("Failed to update. Bus ID may be incorrect.");
        }
    }
}
