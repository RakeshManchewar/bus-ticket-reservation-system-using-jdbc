package Bus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

//======= Login Methods =======
public class LoginMethods 
{
	// ======= Admin Login =======
    public static boolean adminLogin() throws SQLException 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter admin username: ");
        String username = sc.nextLine();

        System.out.print("Enter admin password: ");
        String password = sc.nextLine();

        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        
        con = DBUtil.getConnection();

        String query = "SELECT * FROM admin_users WHERE username = ? AND password = ?";
        pst = con.prepareStatement(query);
        pst.setString(1, username);
        pst.setString(2, password);

        rs = pst.executeQuery();

        if (rs.next()) 
        {
            System.out.println("Admin Login successful.");
            return true;
        }
        else
        {
            System.out.println("Invalid username or password.");
        }
        return false;
    }
    
    // ======= User Login =======
    public static String userLogin() throws SQLException 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter username: ");
        String username = sc.nextLine();

        System.out.print("Enter password: ");
        String password = sc.nextLine();

        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        
        con = DBUtil.getConnection();

        String query = "SELECT * FROM users WHERE username = ? AND password = ?";
        pst = con.prepareStatement(query);
        pst.setString(1, username);
        pst.setString(2, password);

        rs = pst.executeQuery();

        if (rs.next()) 
        {
            System.out.println("Login successful. Welcome, " + username + "!");
            return username;
        } 
        else 
        {
            System.out.println("Invalid username or password.");
        }
        return null;
    }
    
    // ======= User Registration =======
    public static void registerUser() throws SQLException 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Choose a username: ");
        String username = sc.nextLine();

        System.out.print("Choose a password: ");
        String password = sc.nextLine();

        Connection con = null;
        PreparedStatement pst = null;
        
        con = DBUtil.getConnection();

        // Check if user already exists
        String checkQuery = "SELECT * FROM users WHERE username = ?";
        pst = con.prepareStatement(checkQuery);
        pst.setString(1, username);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) 
        {
            System.out.println("Username already taken. Try a different one.");
            return;
        }

        // Insert new user
        String insertQuery = "INSERT INTO users (username, password) VALUES (?, ?)";
        pst = con.prepareStatement(insertQuery);
        pst.setString(1, username);
        pst.setString(2, password);

        int rows = pst.executeUpdate();
        if (rows > 0) 
        {
            System.out.println("Registration successful! You can now log in.");
        }
    }
}
